angular.module('mainApp').controller("homeController",function($timeout,$scope, $location){

});
