angular.module('mainApp').controller("noDataController",function($timeout,$scope){
$scope.noData = 'There is no functionality implemented for this page.....';
});
