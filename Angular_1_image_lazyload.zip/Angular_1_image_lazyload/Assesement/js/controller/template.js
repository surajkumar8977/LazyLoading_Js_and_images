angular.module('mainApp').controller("templateController",function($timeout, $scope){


//$scope.dataTableOpt = {
//   //custom datatable options 
//  // or load data through ajax call also
//  "aLengthMenu": [[10, 50, 100,-1], [10, 50, 100,'All']],
//  };




				// I flag the visibility of the big box.
				$scope.isBoxVisible = true;
 
				// Build up a large set of images, all with unique
				// SRC values so that the browser cannot cache them.
				$scope.photos = buildPhotoSet( 1000 );
 
 
				// ---
				// PUBLIC METHODS.
				// ---
 
 
				// I change the SRC values of the existing photo set
				// in order to examine how changes to source will
				// affect rendered / non-rendered images.
				$scope.changeSource = function() {
 
					var now = ( new Date() ).getTime();
 
					// Update all SRC attribute to point to "1.jpg".
					for ( var i = 0 ; i < $scope.photos.length ; i++ ) {
 
						var photo = $scope.photos[ i ];
 
						photo.src = photo.src.replace( /\d\./i, "1." );
 
					}
 
				};
 
 
				// I clear the current photo set.
				$scope.clearPhotos = function() {
 
					$scope.photos = [];
 
				};
 
 
				// I hide the big box, allowing the document to change
				// its dimensions (and possibly show more images than
				// were visible beforehand).
				$scope.hideBox = function() {
 
					$scope.isBoxVisible = false;
 
				};
 
 
				// I rebuild the entire photo set.
				$scope.rebuildSet = function() {
 
					$scope.photos = buildPhotoSet( 20 );
 
				};
 
 
				// ---
				// PRIVATE METHODS.
				// ---
 
 
				// I return a photo set of the given size. Each photo
				// will have a unique SRC value.
				function buildPhotoSet( size ) {
 
					var photos = [];
					var now = ( new Date() ).getTime();
 
					for ( var i = 0 ; i < size ; i++ ) {
 
						var index = ( ( i % 3 ) + 1 );
						var version = ( now + i );
 
						photos.push({
							id: ( i + 1 ),
							src: ( "https://bennadel.github.io/JavaScript-Demos/demos/lazy-src-angularjs/christina-cox-" + index + ".jpg?v=" + version )
						});
 
					}
 
					return( photos );
 
				}
 
			






});
